// Adapted from S. S. Somé

class Main {
  static public void main(String argv[]) {
    EFrame frame = new EFrame("Easter Date Calculator");
    frame.setSize(270,150);
    frame.setVisible(true);
  }
}
